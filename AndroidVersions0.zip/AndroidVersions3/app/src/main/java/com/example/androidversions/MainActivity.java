package com.example.androidversions;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.androidversions.databinding.ActivityMainBinding;
import com.google.android.material.snackbar.Snackbar;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding mainBinding;
    AndroidVersionAdapter adapter;
    List<AndroidVersion> versionList;
    boolean sortedByName = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());

        versionList = new ArrayList<>();
        versionList.add(new AndroidVersion(R.drawable.ic_donut,       "Donut",              "1.6"));
        versionList.add(new AndroidVersion(R.drawable.ic_eclair,      "Éclair",             "2.0 – 2.1"));
        versionList.add(new AndroidVersion(R.drawable.ic_froyo,       "Froyo",              "2.2 – 2.2.3"));
        versionList.add(new AndroidVersion(R.drawable.ic_gingerbread, "Gingerbread",        "2.3 – 2.3.7"));
        versionList.add(new AndroidVersion(R.drawable.ic_honeycomb,   "Honeycomb",          "3.0 – 3.2.6"));
        versionList.add(new AndroidVersion(R.drawable.ic_ics,         "Ice Cream Sandwich", "4.0 – 4.0.4"));
        versionList.add(new AndroidVersion(R.drawable.ic_jellybean,   "Jelly Bean",         "4.1 – 4.3.1"));
        versionList.add(new AndroidVersion(R.drawable.ic_kitkat,      "KitKat",             "4.4 – 4.4.4"));
        versionList.add(new AndroidVersion(R.drawable.ic_lollipop,    "Lollipop",           "5.0 – 5.1.1"));
        versionList.add(new AndroidVersion(R.drawable.ic_marshmallow, "Marshmallow", "6.0 – 6.0.1"));
        versionList.add(new AndroidVersion(R.drawable.ic_nougat,      "Nougat",  "7.0 – 7.1.2"));
        versionList.add(new AndroidVersion(R.drawable.ic_oreo,        "Oreo",   "8.0 – 8.1"));

        adapter = new AndroidVersionAdapter(versionList, item ->
                Snackbar.make(
                        mainBinding.recyclerView,
                        "You selected: " + item.codeName + " (" + item.version + ")",
                        Snackbar.LENGTH_SHORT
                ).show()
        );

        mainBinding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mainBinding.recyclerView.setAdapter(adapter);

        mainBinding.btnSort.setOnClickListener(v -> {
            if (!sortedByName) {
                adapter.sortByName();
                mainBinding.btnSort.setText("Sort by Version ↓");
                sortedByName = true;
            } else {
                adapter.sortByVersionDesc();
                mainBinding.btnSort.setText("Sort by Name A→Z");
                sortedByName = false;
            }
        });
    }
}