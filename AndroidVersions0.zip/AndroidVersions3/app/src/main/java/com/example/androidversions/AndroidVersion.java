package com.example.androidversions;

public class AndroidVersion {
    int imageResId;
    String codeName;
    String version;

    public AndroidVersion(int imageResId, String codeName, String version) {
        this.imageResId = imageResId;
        this.codeName = codeName;
        this.version = version;
    }
}