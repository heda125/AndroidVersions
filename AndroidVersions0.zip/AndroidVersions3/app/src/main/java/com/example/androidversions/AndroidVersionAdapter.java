package com.example.androidversions;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.androidversions.databinding.ItemAndroidVersionBinding;
import java.text.Collator;
import java.util.List;
import java.util.Locale;

public class AndroidVersionAdapter extends RecyclerView.Adapter<AndroidVersionAdapter.VersionViewHolder> {

    private final List<AndroidVersion> versionList;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(AndroidVersion item);
    }

    public AndroidVersionAdapter(List<AndroidVersion> versionList, OnItemClickListener listener) {
        this.versionList = versionList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public VersionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemAndroidVersionBinding binding = ItemAndroidVersionBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new VersionViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull VersionViewHolder holder, int position) {
        AndroidVersion item = versionList.get(position);
        Context holderContext = holder.itemView.getContext();

        holder.binding.imgLogo.setImageResource(item.imageResId);
        holder.binding.tvCodeName.setText(item.codeName);
        holder.binding.tvVersion.setText("Version: " + item.version);

        // تعيين الألوان الزوجية والفردية بالتبادل بناءً على الـ Position الجديد
        if (position % 2 == 0) {
            holder.binding.cardItem.setCardBackgroundColor(holderContext.getColor(R.color.row_even));
        } else {
            holder.binding.cardItem.setCardBackgroundColor(holderContext.getColor(R.color.row_odd));
        }

        holder.binding.cardItem.setOnClickListener(view -> {
            if (listener != null) {
                listener.onItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return versionList.size();
    }

    // فرز أبجدي ذكي يتجاهل الحركات لتظهر Éclair مع حرف الـ E
    public void sortByName() {
        Collator collator = Collator.getInstance(Locale.US);
        collator.setStrength(Collator.PRIMARY);
        versionList.sort((a, b) -> collator.compare(a.codeName, b.codeName));
        notifyDataSetChanged();
    }

    // فرز تنازلي آمن من خلال استخراج الأرقام فقط وتجنب الـ Crash
    public void sortByVersionDesc() {
        versionList.sort((a, b) -> {
            try {
                String versionA = a.version.split("[^0-9.]")[0];
                String versionB = b.version.split("[^0-9.]")[0];

                double vA = Double.parseDouble(versionA);
                double vB = Double.parseDouble(versionB);
                return Double.compare(vB, vA);
            } catch (Exception e) {
                return b.version.compareTo(a.version);
            }
        });
        notifyDataSetChanged();
    }

    public static class VersionViewHolder extends RecyclerView.ViewHolder {
        final ItemAndroidVersionBinding binding;

        public VersionViewHolder(@NonNull ItemAndroidVersionBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}